#include "init.h"

typedef struct ssd_info {

    struct channel_info* channel[CHANNEL_NUM];
} ssd;

typedef struct channel_info {
    char* isBusy;

    struct way_info* way[WAY_NUM];

} channel;

typedef struct way_info {
    char* isBusy;

    struct die_info* die[DIE_NUM];
} way;

typedef struct die_info {
    char* isBusy;

    struct plane_info* plane[PLANE_NUM];
} die;

typedef struct plane_info {

    // struct block_info *data_block;
    // struct block_info *translation_block;
    struct block_info* block[BLOCK_NUM];
} plane;

typedef struct block_info {
    unsigned int erase_count;
    unsigned int lbn;
    unsigned int pbn;
    int OOB;


    // struct page_info *data_page;
    // struct page_info *translation_page;
    struct page_info* page[PAGE_NUM];
} block;

typedef struct page_info {
    char* state;
    char data[SECTOR_SIZE * PAGE_SIZE * 2];

    struct spare_page_info* spare;
} page;

typedef struct spare_page_info
{
    unsigned int lpn;
    unsigned int write_count;

} sp;

typedef struct ac_time_characteristics {
    int tPROG;     //program time
    int tDBSY;     //bummy busy time for two-plane program
    int tBERS;     //block erase time
    int tPROGO;    //one shot program time
    int tERSL;       //the trans time of suspend / resume operation
    int tCLS;      //CLE setup time
    int tCLH;      //CLE hold time
    int tCS;       //CE setup time
    int tCH;       //CE hold time
    int tWP;       //WE pulse width
    int tALS;      //ALE setup time
    int tALH;      //ALE hold time
    int tDS;       //data setup time
    int tDH;       //data hold time
    int tWC;       //write cycle time
    int tWH;       //WE high hold time
    int tADL;      //address to data loading time
    int tR;        //data transfer from cell to register
    int tAR;       //ALE to RE delay
    int tCLR;      //CLE to RE delay
    int tRR;       //ready to RE low
    int tRP;       //RE pulse width
    int tWB;       //WE high to busy
    int tRC;       //read cycle time
    int tREA;      //RE access time
    int tCEA;      //CE access time
    int tRHZ;      //RE high to output hi-z
    int tCHZ;      //CE high to output hi-z
    int tRHOH;     //RE high to output hold
    int tRLOH;     //RE low to output hold
    int tCOH;      //CE high to output hold
    int tREH;      //RE high to output time
    int tIR;       //output hi-z to RE low
    int tRHW;      //RE high to WE low
    int tWHR;      //WE high to RE low
    int tRST;      //device resetting time
} time;

struct spare_page_info* init_spare_page(struct spare_page_info* spare) {
    spare->write_count = 0;

    // 논의 필요
    spare->lpn = 0;

    return spare;
}

struct page_info* init_page(struct page_info* page) {
    sp* spare;

    for (int i = 0; i < SECTOR_SIZE * PAGE_SIZE * 2; i++)
    {
        page->data[i] = 1;            // -1 == null
    }
    page->state = "null";

    spare = page->spare;
    init_spare_page(spare);

    return page;
}

struct block_info* init_block(struct block_info* block) {
    page* page;

    block->erase_count = 0;
    block->OOB = PAGE_NUM - 1;        // 항상 마지막 페이지

    // 수정필요
    block->lbn = 0;
    block->pbn = 0;

    for (int i = 0; i < PAGE_NUM; i++)
    {
        page = block->page[i];
        page = init_page(page);              // 블록 페이지 수 만큼 초기화
    }

    return block;
}

struct plane_info* init_plane(struct plane_info* plane) {
    block* block;

    for (int i = 0; i < BLOCK_NUM; i++)
    {
        block = plane->block[i];
        init_block(block);                  // 플래인 블록 수 만큼 초기화
    }

    return plane;
}

struct die_info* init_die(struct die_info* die) {
    plane* plane;

    die->isBusy = "idle";

    for (int i = 0; i < PLANE_NUM; i++)
    {
        plane = die->plane[i];
        init_plane(plane);                  // 다이 플래인 수 만큼 초기화
    }

    return die;
}

struct way_info* init_way(struct way_info* way) {
    die* die;

    way->isBusy = "idle";

    for (int i = 0; i < DIE_NUM; i++)
    {
        die = way->die[i];
        init_die(die);                  // 칩 다이 수만큼 초기화
    }

    return way;
}

struct channel_info* init_channel(struct channel_info* channel) {
    way* way;

    channel->isBusy = "idle";

    for (int i = 0; i < WAY_NUM; i++)
    {
        way = channel->way[i];
        init_way(way);                  // 채널 칩 수 만큼 초기화
    }

    return channel;
}


struct ssd_info* init_ssd(struct ssd_info* ssd) {
    channel *channel;

    for (int i = 0; i < CHANNEL_NUM; i++)
    {
        channel = ssd->channel[i];
        init_channel(channel);                  // 채널 수 만큼 초기화
    }

    return ssd;
}

struct ac_time_characteristics* init_time(struct ac_time_characteristics* time) {
    // 초기 값 넣으면 댑니다.

    int tPROG;     //program time
    int tDBSY;     //bummy busy time for two-plane program
    int tBERS;     //block erase time
    int tPROGO;    //one shot program time
    int tERSL;       //the trans time of suspend / resume operation
    int tCLS;      //CLE setup time
    int tCLH;      //CLE hold time
    int tCS;       //CE setup time
    int tCH;       //CE hold time
    int tWP;       //WE pulse width
    int tALS;      //ALE setup time
    int tALH;      //ALE hold time
    int tDS;       //data setup time
    int tDH;       //data hold time
    int tWC;       //write cycle time
    int tWH;       //WE high hold time
    int tADL;      //address to data loading time
    int tR;        //data transfer from cell to register
    int tAR;       //ALE to RE delay
    int tCLR;      //CLE to RE delay
    int tRR;       //ready to RE low
    int tRP;       //RE pulse width
    int tWB;       //WE high to busy
    int tRC;       //read cycle time
    int tREA;      //RE access time
    int tCEA;      //CE access time
    int tRHZ;      //RE high to output hi-z
    int tCHZ;      //CE high to output hi-z
    int tRHOH;     //RE high to output hold
    int tRLOH;     //RE low to output hold
    int tCOH;      //CE high to output hold
    int tREH;      //RE high to output time
    int tIR;       //output hi-z to RE low
    int tRHW;      //RE high to WE low
    int tWHR;      //WE high to RE low
    int tRST;      //device resetting time

    return time;
};
