#include "init.h"

int main()
{
    struct ssd_info* ssd [1];
    init_ssd(ssd);

    printf("hello\n");

    return 0;
}






int main()
{
    struct ssd_info* ssd;
    ssd = (struct ssd_info*)malloc(sizeof(struct ssd_info));
    init_ssd(ssd);

    printf("hello\n");

    return 0;
}



