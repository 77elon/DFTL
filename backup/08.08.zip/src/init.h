#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHANNEL_NUM 5
#define WAY_NUM 5
#define DIE_NUM 4
#define PLANE_NUM 4

#define BLOCK_NUM 10
#define DATA_BLOCK_NUM 10

// DFTL
#define TRANSLATION_BLOCK_NUM 2

#define PAGE_NUM 32

#define SECTOR_SIZE 512
#define PAGE_SIZE 4

typedef struct ssd_info ssd;
typedef struct channel_info channel;
typedef struct way_info way;
typedef struct die_info die;
typedef struct plane_info plane;
typedef struct block_info block;
typedef struct page_info page;
typedef struct spare_page_info sp;
typedef struct ac_time_characteristics time;


struct ssd_info* init_ssd(struct ssd_info* ssd);
struct channel_info* init_channel(struct channel_info* channel);
struct way_info* init_way(struct way_info* way);
struct die_info* init_die(struct die_info* die);
struct plane_info* init_plane(struct plane_info* plane);
struct block_info* init_block(struct block_info* block);
struct page_info* init_page(struct page_info* page);
struct spare_page_info* init_spare_page(struct spare_page_info* spare);
struct ac_time_characteristics* init_time(struct ac_time_characteristics* time);
